#include<iostream>
#include<fstream>
#include<string>
#include <cstdlib>
#include <vector>
#include<map>
using namespace std;
//#define SIZE 50
char line_a[50];
char line[50];
map<string,string> mymap;

int main()
{      
    fstream data, out;
    data.open("test1.txt",ios::in);
    vector<string> new_data;
	
    while(data.getline(line_a,sizeof(line_a),'\n'))
    {   string data;
	    data.assign(line_a);
	       
		if(data.substr(0,1) == "2")
		   new_data.push_back(data);
	}
	  
	data.close();

    string time_old = "=="; 
	vector<string> cal;
	
	out.open("result.txt",ios::out);
	for(size_t i =0; i< new_data.size(); i++)  
	{  
	    string my_data;
	    my_data.assign(new_data[i]);
	    
		size_t d_e = my_data.find_first_of(" ");
		size_t t_e = my_data.find_first_of("\t")-7;
	    size_t t_s = my_data.find_first_of(" ")+2;
		string value_temp = my_data.substr(t_e+8,1);    //1 or 0
		string time_sec = my_data.substr(t_s+6,2);
		string time_all = my_data.substr(t_s,t_e-t_s);
		
		if(i == 0)
		out<<"Date : "<<endl<<my_data.substr(0,d_e)<<endl;	  
		if( time_sec == time_old ||i == 0)
		{   
			cal.push_back(value_temp);
            time_old = time_sec ;
        }
		else
		{
			int zero =0,one =0;
			for(size_t j =0; j< cal.size(); j++)
			{
			    if(cal[j] == "0")
					zero++;
				else
				    one++;
			} 
			if(zero > one )
				mymap.insert(pair<string,string>(time_all,"0"));
			else
			    mymap.insert(pair<string,string>(time_all,"1"));
				
            cal.clear();
			cal.push_back(value_temp);	
			time_old = time_sec ;
		}
    }
    mymap.insert(pair<string,string>("end","0"));
    int count =0;
    for (std::map<string,string>::iterator it=mymap.begin(); it!=mymap.end(); ++it)
    {   
    	if( it == mymap.begin() && it -> second == "1")
    	{   count++;
		    out<<"Interval:("<<count<<")"<<endl<< it->first<<endl  ;
    	}   
        else if( it != mymap.begin()) 
		{ it--;
		  string temp = it ->second ;
		  string temp_t = it ->first;
		  it++; 
		  if( temp == "0" && it->second == "1" )
		  {  count++;
		     out <<"Interval ("<<count<<")"<<endl<< it->first<<endl  ;
		  }
          else if(temp == "1" && it->second == "0")
             out <<temp_t <<endl;
        }
        
    }  	
    out.close();

} 




